AMURA: НЕ ОБОРАЧИВАЙСЯ — Android-проект

ВАЖНО:
Это исходный Android-проект, упаковывающий рабочую резервную HTML-версию в Android WebView.
Это ещё НЕ готовый APK. Для сборки нужен Android Studio с Android SDK и Gradle.

Как собрать APK:
1. Установить Android Studio на компьютер.
2. Распаковать архив.
3. В Android Studio выбрать Open и указать папку AMURA_Android_Project.
4. Дождаться синхронизации Gradle и установки Android SDK Platform 35, если потребуется.
5. Выбрать Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Для 3D-библиотеки Three.js в HTML используется CDN jsdelivr, поэтому при запуске игры требуется интернет.
Исходная HTML-версия сохранена в app/src/main/assets/index.html без изменений.
